package com.mnsoft.evaluation.application;

public class EvaluationAOC {
	
	public static void main(String[] args) {
	}

}
